package clearchat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;


public class ClearChat extends JavaPlugin {
	
	@Override
	public void onEnable() {
		getLogger().info("ClearChat enabled!");
		System.out.println("Thanks for using ClearChat by DerTheDev!");
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("cc")) {
			if(sender instanceof Player) {
				Player player = (Player) sender;
				if (args.length == 0) { // Main ClearChat command
					if (player.hasPermission("clearchat.cc")) {
						for (int i = 0; i < 99; i++) {
							Bukkit.broadcastMessage(" ");
						}
						
						Bukkit.broadcastMessage(ChatColor.BLUE + "Chat has been cleared by" + player);
					} else {
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cYou are lacking the permission node: &4chatcolor.cc"));
					}
				} else if (args.length == 1) { //other commands, such as cc info and cc help, or cc all
					if (args[0].equalsIgnoreCase("all")) { //cc all
						for (int i = 0; i < 99; i++) {
							Bukkit.broadcastMessage(" ");
						}
						
						Bukkit.broadcastMessage(ChatColor.BLUE + "Chat has been cleared by" + player);
						
					} else if (args[0].equalsIgnoreCase("help")) { //cc help
						sender.sendMessage(ChatColor.BLUE + "----- ClearChat help -----");
						sender.sendMessage("/cc - Clears the global chat.");
						sender.sendMessage("/cc all - Clears the global chat.");
						sender.sendMessage("/cc help - Shows help for ClearChat.");
						sender.sendMessage("/cc info - Shows info for ClearChat");
						sender.sendMessage("/cmc - Clears your own chat.");
						sender.sendMessage(ChatColor.BLUE + "----- ClearChat help -----");
						
					} else if (args[0].equalsIgnoreCase("info")) { //cc info
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&9&lClearChat info:"));
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&9Developer: &7DerTheDev"));
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&9Version: &71.1"));
						
					} else if (args[0].equalsIgnoreCase("all")) { //cc all (same as cc)
						if (player.hasPermission("clearchat.cc")) {
							for (int i = 0; i < 99; i++) {
								Bukkit.broadcastMessage(" ");
							}
							
							Bukkit.broadcastMessage(ChatColor.BLUE + "Chat has been cleared by" + player);
						} else {
							sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cYou are lacking the permission node: &4chatcolor.cc"));
						}
					} else {
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cInvalid subcommand '&4" + args + "&c'"));
					}
				} else {
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cToo many args!"));
				}
			} else {
				sender.sendMessage(ChatColor.RED + "This command is usually performed by players");
			}
		}
		
		if (cmd.getName().equalsIgnoreCase("cmc")) {
			if (sender instanceof Player) {
				Player player = (Player) sender;
				if (player.hasPermission("clearchat.cmc")) {
				
					for (int i = 0; i < 99; i++) {
						player.sendMessage(" ");
					}
					
					player.sendMessage(ChatColor.BLUE + "You just cleared your own chat, " + player + "!");				
				} else {
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cYou are lacking the permission node: &4chatcolor.cmc"));
				}
			} else {
				sender.sendMessage(ChatColor.RED + "This command is usually performed by players");
			}
		}
	return false;
	}
	
	@Override
	public void onDisable() {
		getLogger().info("ClearChat disabled");
	}
}
