package clearchat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;


public class ClearChat extends JavaPlugin {
	
	@Override
	public void onEnable() {
		getLogger().info("ClearChat enabled!");
		System.out.println("Thanks for using ClearChat by DerTheDev!");
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("cc")) {
			if(sender instanceof Player) {
				Player player = (Player) sender;
				if (player.hasPermission("clearchat.cc")) {
					for (int i = 0; i < 99; i++) {
						Bukkit.broadcastMessage(" ");
					}
					
					Bukkit.broadcastMessage(ChatColor.BLUE + "Chat has been cleared by" + player);
					
					return true;
				} else {
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cYou are lacking the permission node: &4chatcolor.cc"));
				}
			} else {
				sender.sendMessage(ChatColor.RED + "This command is usually performed by players");
			}
		}
		
		if (cmd.getName().equalsIgnoreCase("cchelp")) {
			sender.sendMessage(ChatColor.BLUE + "ClearChat help:");
			sender.sendMessage("/cc - Clears the global chat.");
			sender.sendMessage("/cmc - Clears your own chat.");
			sender.sendMessage("/ccinfo - Shows the plugin's info");
			
			return true;
		}
		
		if (cmd.getName().equalsIgnoreCase("cmc")) {
			if (sender instanceof Player) {
				Player player = (Player) sender;
				if (player.hasPermission("clearchat.cmc")) {
				
					for (int i = 0; i < 99; i++) {
						player.sendMessage(" ");
					}
					
					player.sendMessage(ChatColor.BLUE + "You just cleared your own chat, " + player + "!");				
				} else {
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&l&9[ClearChat] &cYou are lacking the permission node: &4chatcolor.cmc"));
				}
			} else {
				sender.sendMessage(ChatColor.RED + "This command is usually performed by players");
			}
		}
		
		if (cmd.getName().equalsIgnoreCase("ccinfo")) {
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&9&lClearChat info:"));
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&9Developer: &7DerTheDev"));
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&9Version: &71.0"));
		}
		
		return false;
	}
	
	@Override
	public void onDisable() {
		getLogger().info("ClearChat disabled");
	}
}
